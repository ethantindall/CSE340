<img src="/phpmotors/images/site/logo.png" alt="Company Logo">
        <a id="acctLink" href="#">My Account</a>